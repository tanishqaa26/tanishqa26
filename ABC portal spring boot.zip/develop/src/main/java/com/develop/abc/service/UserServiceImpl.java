package com.develop.abc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.develop.abc.dao.Userdao;
import com.develop.abc.dto.Users;
@Component
@Service("userService")
public class UserServiceImpl implements UserService {
	private PasswordEncoder passwordencoder;
	@Autowired
	Userdao Udao;
	Users user;

List<Users> userDetails = new ArrayList<Users>();
	
	@Override
	public void AddUserDetails(Users us) {
		// TODO Auto-generated method stub
		us.setRole("USER");
		us.setPassword(passwordencoder.encode(us.getPassword()));
		 Udao.save(us);
		}
	
	@Autowired
	public UserServiceImpl(PasswordEncoder encoder) {
	// TODO Auto-generated constructor stub
		this.passwordencoder=encoder;
	}
	
	

	@Override
	public List<Users> showAllUser() {
		List<Users> database = Udao.findAll();
		return database;
	}
	
//	@Override
//	public Users showUser(String username) {
//		for(Users us : userDetails) {
//			if(usr.getUserName().equals(username)){
//				System.out.println(us);
//				return us;
//			}
//		}
//		return null;
//	}
	
	@Override
	public void deleteData(Long id) {
		Udao.deleteById(id);
	}
	
	@Override
	public Users SearchUser(Long id) {
		
		Optional<Users> myData=Udao.findById(id);
Users p=myData.get();
		return p;
		
		
	}
	
	@Override
    public Users showUser(String username ) {
        // TODO Auto-generated method stub
        user = Udao.findBylUserName(username);
//        User M=user.();
        
        return user;

}

	@Override
	public String update(Users us) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteData(int userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Users SearchUser(int lid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addUser(Users us) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Users viewProfile(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Users viewProfiles(String username) {
		// TODO Auto-generated method stub
		return null;
	}


}