package com.develop.abc.dto;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.develop.abc.security.Role;

@Entity
@Table(name="administer")

public class Users {
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long lid;
	private String lname;
	private String lemail;
	private String lUserName;
	private String password;
	private Long lage;
	private String laddress;
	private Long phone;
	private String role;
	

	{
		

	
	
}

	public Long getLid() {
		return lid;
	}

	public void setLid(Long lid) {
		this.lid = lid;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getLemail() {
		return lemail;
	}

	public void setLemail(String lemail) {
		this.lemail = lemail;
	}

	public String getlUserName() {
		return lUserName;
	}

	public void setlUserName(String lUserName) {
		this.lUserName = lUserName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getLage() {
		return lage;
	}

	public void setLage(Long lage) {
		this.lage = lage;
	}

	public String getLaddress() {
		return laddress;
	}

	public void setLaddress(String laddress) {
		this.laddress = laddress;
	}

	public Long getPhone() {
		return phone;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	


	public Users(Long lid, String lname, String lemail, String lUserName, String password, Long lage, String laddress,
			Long phone, String role) {
		super();
		this.lid = lid;
		this.lname = lname;
		this.lemail = lemail;
		this.lUserName = lUserName;
		this.password = password;
		this.lage = lage;
		this.laddress = laddress;
		this.phone = phone;
		this.role = role;
	}

	@Override
	public String toString() {
		return "Users [lid=" + lid + ", lname=" + lname + ", lemail=" + lemail + ", lUserName=" + lUserName
				+ ", password=" + password + ", lage=" + lage + ", laddress=" + laddress + ", phone=" + phone
				+ ", role=" + role + "]";
	}

}
	
	

	