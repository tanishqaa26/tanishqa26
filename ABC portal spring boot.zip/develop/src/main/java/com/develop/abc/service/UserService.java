package com.develop.abc.service;


import java.util.List;

import com.develop.abc.dto.Users;

public interface UserService {
	
	public List<Users> showAllUser();
	public Users showUser(String lUserName);
	public void deleteData(int userId);
	public Users SearchUser(int lid);
	String addUser(Users us);
	void AddUserDetails(Users us);
	Users viewProfile(String username);
	Users viewProfiles(String username);
	void deleteData(Long lid);
	public Users SearchUser(Long lid);
	String update(Users us);

	
	
	}