package com.develop.abc.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.develop.abc.dto.Users;

public interface UserRepository extends JpaRepository<Users, Long> {

	Users findBylUserName(String lUserName);
}
