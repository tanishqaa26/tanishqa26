package com.portal.Cars.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.portal.Cars.dto.Car;
import com.portal.Cars.dto.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByMailid(String name);

	Optional<User> findByUserName(String username);

	@Query("SELECT p FROM User p WHERE CONCAT(p.userName) LIKE %?1%")
	public User search(String keyword);

	

	
	
}
