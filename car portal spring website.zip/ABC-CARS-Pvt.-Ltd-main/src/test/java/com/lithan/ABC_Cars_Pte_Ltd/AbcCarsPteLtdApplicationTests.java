package com.lithan.ABC_Cars_Pte_Ltd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcCarsPteLtdApplicationTests {

	@Test
	void contextLoads() {
	}

}
