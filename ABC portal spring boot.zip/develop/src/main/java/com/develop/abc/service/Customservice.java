package com.develop.abc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.develop.abc.dao.UserRepository;
import com.develop.abc.dto.Users;
import com.develop.abc.security.ApplicationUserDetails;

@Service
	public class Customservice implements UserDetailsService {
	    @Autowired
		UserRepository userrepo;
	    Users user;
		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			// TODO Auto-generated method stub
			user=userrepo.findBylUserName(username);
			if(user==null) {
					System.out.println("User name is Invalid");
				}
				
			return new ApplicationUserDetails(user);
		}
			
	}


