package com.portal.Cars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ABCCarsPteLtdApplication {

	public static void main(String[] args) {
		SpringApplication.run(ABCCarsPteLtdApplication.class, args);
	}

}
