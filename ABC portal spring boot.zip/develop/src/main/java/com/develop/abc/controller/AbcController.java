package com.develop.abc.controller;

import java.beans.JavaBean;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.develop.abc.dto.Users;
import com.develop.abc.service.UserService;


@JavaBean
@Controller
public class AbcController {
	@Autowired
	UserService userService;
	List<Users> userDetailzzz = new ArrayList<Users>();
	Users user;
	
	@GetMapping( value ="/")
	public String home() {
		return "welcome";
	}
	
	@GetMapping( value ="/homie")
	public String homeafter() {
		return "Home";
	}
	
	
	@GetMapping( value ="/showd")
	public ModelAndView show(@ModelAttribute("data") Users usr ) {
		return new ModelAndView("showd");
	}
	
	@PostMapping(value ="/showd")
	public ModelAndView showUser() {
		 List<Users> userDetailzzz = userService.showAllUser();
		System.out.println(userDetailzzz);
		return new ModelAndView("showd","testv",userDetailzzz);
	}
	
	@GetMapping( value ="/thankyou")
	public String thankyou() {
		return "thankyou";
	}
	
	@GetMapping(value="/search")
    public String membersearch(@ModelAttribute("searchd") Users lid) {
        
        return "SearchLearner";
    }
    
    @PostMapping(value = "/sear")
    public ModelAndView membesearch(@ModelAttribute("searchd") Users username) {
    	String searchname = username.getlUserName();
        Users mm = userService.showUser(searchname);
        
        System.out.println(mm);
        
        return new ModelAndView("SearchResult","arves",mm);
//      return "SearchResultMember";
    }

  //delete user
  	@GetMapping(value = "/delete")
  	public String dis_del()
  	{
  		return "deletelearn";	
  	}
  	

  	@PostMapping(value ="/delete")
  	public String DeleteUser(@PathVariable("searchid") Integer lid)
  	{
  		userService.deleteData(lid);
  		return "redirect:/showd";
  	}
  	//
    
	

	@GetMapping( value ="/user")
	public String HomeUser() {
		return "HomeUser";
	}

	
	@GetMapping( value ="/admin")
	public String HomeAdmin() {
		return "HomeAdmin";
	}
	
	@GetMapping(value= "/login")
	public String login() {
		return "login";
	}
	
	@GetMapping(value = "/register")
	public String myRegisterPage(@ModelAttribute("data") Users us) {
		
		
		return "register";
		
	}
	@PostMapping(value = "/myreg")
	public String addRegisterPage(@ModelAttribute("lid") Users us) {
		userService.AddUserDetails(us);
		return "redirect:/thankyou";
		}
		
	

	@RequestMapping("/dashboard")
	public ModelAndView dashboard() {
		//model.put("userId",userId);
		return new ModelAndView("dashboard");
	}
		
		
	
	
	//@PostMapping(value = "/login")
	//public String welcomePage(ModelMap model, @RequestParam String lid, @RequestParam String password) {
		//if (lid.equals("user")&& password.equals("root")) {
			//	model.put("lid", lid);
				//return "HomeUser";
			//}
			
			
		
		//model.put("errorMsg", "Please provide the correct userid and password");
		//return "login";
	//}
	
	
	@GetMapping( value ="/manage")
	public String manage() {
		return "manage";
	}
	
	@GetMapping( value ="/addL")
	public ModelAndView add(@ModelAttribute("data") Users usr ) {
		return new ModelAndView("LearnerDetails");
	}
	
	@PostMapping( value ="/addL")
	public String addUser(@ModelAttribute("data") Users usr) {
		userService.AddUserDetails(usr);
		System.out.println(usr);
		return "redirect:/thankyou";
	}
	
	@GetMapping( value ="/update")
	public ModelAndView update(@ModelAttribute("data") Users usr ) {
		return new ModelAndView("UpdateProfile");
	}
	
	@PostMapping( value ="/update")
	public String updated(@ModelAttribute("data") Users usr) {
		userService.AddUserDetails(usr);
		System.out.println(usr);
		return "redirect:/showd";
	}
	
	
	
	
	

	
	
	
	

		
	

	
}

