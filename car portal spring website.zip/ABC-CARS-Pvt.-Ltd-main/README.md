# ABC-CARS-Pvt.-Ltd
Academic Project

Developed an ABC Cars portal using the spring boot framework with spring security using spring tool suite IDE. 

In this ABC Cars portal, Users will be able to register in the portal using the Registration Page. Users of the portal can search for Cars using the Price Range and model name. Users will be able to view the Car information after searching them. The portal allows users to log in, post Car for sale also update their own profile after logging in.

Whereas the admin can log in to the portal, View List of Registered Users can update user details or can also delete them. Mark a User as Administrator. Update their own profile. Whereas they can also add car details, update the car details, or delete the car details registered in the portal. Admin too has the feature of searching the car using price range and model name.

All this data is stored in the MYSQL database.
